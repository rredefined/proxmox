<?php

use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'auth'])->group(function () {
    Route::get('/aerox-dashboard', function () {
        return view('aeroxdark::dashboard');
    });
});
