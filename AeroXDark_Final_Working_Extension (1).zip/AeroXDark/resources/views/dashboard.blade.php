@extends('layouts.app')

@section('content')
<div style="padding:40px;">
    <h1 style="font-size:28px;">AeroX Dark Extension Loaded Successfully 🚀</h1>
</div>
@endsection
